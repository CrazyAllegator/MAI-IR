﻿#ifndef MURMUR_HASH2_H
#define MURMUR_HASH2_H

unsigned int murmur_hash2(char * key, unsigned int len);


#endif // MURMUR_HASH2_H
